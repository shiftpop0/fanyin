# coding=utf-8
# Copyright 2026 The Alibaba Qwen team.
# SPDX-License-Identifier: Apache-2.0
"""
Tailect ASR 本地方言转写工作台
集成功能：视频支持、角色识别、高精度断句、自动存档、浏览器唤起
"""

import argparse
import base64
import datetime
import io
import json
import os
import platform
import re
import subprocess
import tempfile
import time
import webbrowser
from typing import Any, Dict, List, Optional, Tuple, Union

import gradio as gr
import httpx
import numpy as np
import torch
from qwen_asr import Qwen3ASRModel
from scipy.io.wavfile import write as wav_write
from modelscope.pipelines import pipeline

# ================= 说话人识别 (CAM++) 初始化逻辑 =================

sd_pipeline_instance = None
SD_MODEL_ID = 'iic/speech_campplus_speaker-diarization_common'
SD_MODEL_REL = os.path.join('models', 'iic', 'speech_campplus_speaker-diarization_common')
SD_CHILD_MODELS = {
    "speaker_model": "damo/speech_campplus_sv_zh-cn_16k-common",
    "change_locator": "damo/speech_campplus-transformer_scl_zh-cn_16k-common",
    "vad_model": "damo/speech_fsmn_vad_zh-cn-16k-common-pytorch",
}


def _speaker_diarization_supported() -> bool:
    return True


def _path_if_model_dir(path: Optional[str]) -> Optional[str]:
    """Return a usable local ModelScope model directory if it exists."""
    if not path:
        return None
    candidate = os.path.abspath(os.path.expanduser(str(path)))
    if not os.path.isdir(candidate):
        return None
    markers = ("configuration.json", "config.yaml", ".msc")
    if any(os.path.exists(os.path.join(candidate, marker)) for marker in markers):
        return candidate
    return None


def _find_local_sd_model() -> Optional[str]:
    """Prefer the bundled CAM++ model directory so speaker diarization works offline."""
    env_candidates = [
        os.environ.get("TAILECT_SD_MODEL_PATH"),
        os.environ.get("SPEAKER_DIARIZATION_MODEL"),
    ]

    cache_root = os.environ.get("MODELSCOPE_CACHE")
    root_candidates = [
        os.environ.get("TAILECT_ROOT"),
        os.getcwd(),
    ]

    candidates: List[Optional[str]] = []
    candidates.extend(env_candidates)
    if cache_root:
        candidates.append(os.path.join(cache_root, SD_MODEL_REL))
    for root in root_candidates:
        if not root:
            continue
        candidates.extend([
            os.path.join(root, "models", SD_MODEL_REL),
            os.path.join(root, SD_MODEL_REL),
        ])

    for candidate in candidates:
        model_dir = _path_if_model_dir(candidate)
        if model_dir:
            return model_dir
    return None


def _find_modelscope_model_dir(model_id: str) -> Optional[str]:
    """Resolve a ModelScope model id to a bundled cache directory."""
    parts = str(model_id or "").replace("\\", "/").split("/")
    if len(parts) != 2:
        return _path_if_model_dir(model_id)

    org, name = parts
    cache_root = os.environ.get("MODELSCOPE_CACHE")
    roots = [
        os.environ.get("TAILECT_ROOT"),
        os.getcwd(),
    ]
    candidates: List[Optional[str]] = []
    if cache_root:
        candidates.append(os.path.join(cache_root, "models", org, name))
    for root in roots:
        if not root:
            continue
        candidates.extend([
            os.path.join(root, "models", "models", org, name),
            os.path.join(root, "models", org, name),
        ])
    for candidate in candidates:
        model_dir = _path_if_model_dir(candidate)
        if model_dir:
            return model_dir
    return None


def _patch_sd_configuration_for_offline(model_dir: Optional[str]) -> None:
    """Point nested diarization model ids at local model directories when available."""
    if not model_dir:
        return
    config_path = os.path.join(model_dir, "configuration.json")
    if not os.path.exists(config_path):
        return
    try:
        with open(config_path, "r", encoding="utf-8") as f:
            cfg = json.load(f)
        model_cfg = cfg.get("model") or {}
        changed = False
        missing = []
        for key, model_id in SD_CHILD_MODELS.items():
            local_dir = _find_modelscope_model_dir(model_id)
            if local_dir:
                if model_cfg.get(key) != local_dir:
                    model_cfg[key] = local_dir
                    changed = True
            else:
                missing.append(f"{key}={model_id}")
        if changed:
            cfg["model"] = model_cfg
            with open(config_path, "w", encoding="utf-8") as f:
                json.dump(cfg, f, ensure_ascii=False, indent=4)
            print("已将说话人分离子模型配置为本地路径。")
        if missing:
            print("以下说话人分离子模型未找到本地目录，离线环境可能不可用：" + "；".join(missing))
    except Exception as e:
        print(f"修正说话人分离离线配置失败，继续尝试原配置：{e}")


def get_sd_pipeline():
    """懒加载说话人分离流水线"""
    global sd_pipeline_instance
    if sd_pipeline_instance is None:
        print("正在初始化说话人分离流水线 (CAM++)...")
        tailect_root = os.path.abspath(os.path.expanduser(os.environ.get("TAILECT_ROOT") or os.getcwd()))
        os.environ.setdefault("MODELSCOPE_CACHE", os.path.join(tailect_root, "models"))
        local_model = _find_local_sd_model()
        model_ref = local_model or SD_MODEL_ID
        if local_model:
            print(f"说话人分离使用本地模型目录：{local_model}")
            _patch_sd_configuration_for_offline(local_model)
        else:
            print(f"未找到本地说话人分离模型，尝试使用 ModelScope 模型 ID：{SD_MODEL_ID}")
        try:
            sd_pipeline_instance = pipeline(
                task='speaker-diarization',
                model=model_ref,
                device="cuda" if torch.cuda.is_available() else "cpu"
            )
            print("说话人分离流水线初始化成功！")
        except Exception as e:
            print(f"说话人分离初始化失败: {e}")
            return None
    return sd_pipeline_instance

def calculate_iou(s1, e1, s2, e2):
    """计算两个时间段的重叠长度，用于匹配说话人角色"""
    overlap = max(0, min(e1, e2) - max(s1, s2))
    return overlap

# ================= 辅助工具函数 =================

def _title_case_display(s: str) -> str:
    s = (s or "").strip().replace("_", " ")
    return " ".join([w[:1].upper() + w[1:] if w else "" for w in s.split()])

def _build_choices_and_map(items: Optional[List[str]]) -> Tuple[List[str], Dict[str, str]]:
    if not items: return [], {}
    display = [_title_case_display(x) for x in items]
    mapping = {d: r for d, r in zip(display, items)}
    return display, mapping

def _friendly_checkpoint_name(path: Optional[str]) -> str:
    raw = (path or "").replace("\\", "/")
    low = raw.lower()
    if "tiantai" in low:
        return "Tailect Tiantai"
    if "qwen3-asr-0.6b" in low:
        return "Tailect Base 0.6B"
    if "forcedaligner" in low or "aligner" in low:
        return "时间戳对齐器"
    if not raw:
        return "未加载"
    name = os.path.basename(raw.rstrip("/"))
    return name or "未加载"

def _dtype_from_str(s: str) -> torch.dtype:
    s = (s or "").strip().lower()
    if s in ("bf16", "bfloat16"): return torch.bfloat16
    if s in ("fp16", "float16", "half"): return torch.float16
    return torch.float32

def _format_srt_time(s: float) -> str:
    """将秒数转换为 SRT 标准格式 00:00:00,000"""
    td = datetime.timedelta(seconds=float(s))
    total_seconds = int(td.total_seconds())
    hours = total_seconds // 3600
    minutes = (total_seconds % 3600) // 60
    seconds = total_seconds % 60
    millis = int(td.microseconds / 1000)
    return f"{hours:02d}:{minutes:02d}:{seconds:02d},{millis:03d}"

def _convert_media_to_standard_wav(input_path: str) -> str:
    """预处理媒体文件，解决视频读取导致的 CUDA 报错"""
    temp_wav = tempfile.mktemp(suffix="_standard.wav")
    try:
        cmd = ["ffmpeg", "-y", "-i", input_path, "-vn", "-acodec", "pcm_s16le", "-ar", "16000", "-ac", "1", temp_wav]
        subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True)
        return temp_wav
    except:
        return input_path

def _generate_srt_content(full_text: str, timestamps: List[Dict], sd_result: Any = None, max_chars: int = 20, split_by_punc: bool = True) -> str:
    """高精度断句逻辑"""
    if not timestamps or not full_text: return ""
    pattern = r'([^，。！？；：,.!?:; \n]+[，。！？；：,.!?:; \n]*)'
    segments = re.findall(pattern, full_text)
    
    def get_pure_len(text):
        return len(re.sub(r'[^a-zA-Z0-9\u4e00-\u9fff]', '', text))

    srt_lines, ts_idx, line_idx = [], 0, 1
    current_line_ts, current_line_text = [], ""

    for seg_text in segments:
        seg_pure_len = get_pure_len(seg_text)
        if seg_pure_len == 0:
            current_line_text += seg_text
            continue
        
        matched_len, seg_start_idx = 0, ts_idx
        while ts_idx < len(timestamps) and matched_len < seg_pure_len:
            tk_text = timestamps[ts_idx].get('text', '')
            matched_len += get_pure_len(tk_text)
            ts_idx += 1
        
        if ts_idx > seg_start_idx:
            current_line_ts.extend(timestamps[seg_start_idx:ts_idx])
        
        current_line_text += seg_text
        punc_end = re.search(r'[，。！？；：,.!?:;\n]\s*$', seg_text)
        length_overflow = get_pure_len(current_line_text) >= max_chars

        if (split_by_punc and punc_end) or length_overflow:
            if current_line_ts:
                s_time, e_time = current_line_ts[0]["start_time"], current_line_ts[-1]["end_time"]
                spk_label = ""
                if sd_result and "text" in sd_result:
                    max_overlap, best_spk = 0, "未知"
                    for spk_seg in sd_result["text"]:
                        f = 1000.0 if spk_seg[1] > e_time * 10 else 1.0
                        overlap = calculate_iou(s_time, e_time, spk_seg[0]/f, spk_seg[1]/f)
                        if overlap > max_overlap:
                            max_overlap, best_spk = overlap, spk_seg[2]
                    if max_overlap > 0: spk_label = f"[角色 {best_spk}] "

                start_str = _format_srt_time(s_time)
                end_str = _format_srt_time(e_time)
                srt_lines.append(f"{line_idx}\n{start_str} --> {end_str}\n{spk_label}{current_line_text.strip()}\n")
                line_idx += 1
                current_line_ts, current_line_text = [], ""

    if current_line_ts:
        start_str = _format_srt_time(current_line_ts[0]["start_time"])
        end_str = _format_srt_time(current_line_ts[-1]["end_time"])
        srt_lines.append(f"{line_idx}\n{start_str} --> {end_str}\n{current_line_text.strip()}\n")
    return "\n".join(srt_lines)

def _normalize_audio(wav, eps=1e-12, clip=True):
    x = np.asarray(wav)
    if np.issubdtype(x.dtype, np.integer):
        info = np.iinfo(x.dtype)
        y = x.astype(np.float32) / max(abs(info.min), info.max) if info.min < 0 else (x.astype(np.float32) - (info.max+1)/2.0) / ((info.max+1)/2.0)
    elif np.issubdtype(x.dtype, np.floating):
        y = x.astype(np.float32)
        m = np.max(np.abs(y)) if y.size else 0.0
        if m > 1.0 + 1e-6: y = y / (m + eps)
    else: raise TypeError(f"不支持的类型: {x.dtype}")
    if clip: y = np.clip(y, -1.0, 1.0)
    if y.ndim > 1: y = np.mean(y, axis=-1).astype(np.float32)
    return y

def _coerce_special_types(d: Dict[str, Any]) -> Dict[str, Any]:
    out = {}
    for k, v in d.items():
        if k == "dtype" and isinstance(v, str): out[k] = _dtype_from_str(v)
        else: out[k] = v
    return out

def _merge_dicts(base: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
    out = dict(base)
    out.update(override)
    return out

def _default_backend_kwargs(backend: str) -> Dict[str, Any]:
    if backend == "transformers": return dict(dtype=torch.bfloat16, device_map="cuda:0", max_inference_batch_size=4, max_new_tokens=512)
    return dict(gpu_memory_utilization=0.8, max_inference_batch_size=4, max_new_tokens=4096)

def _default_aligner_kwargs() -> Dict[str, Any]:
    return dict(dtype=torch.bfloat16, device_map="cuda:0")


def _prepare_local_web_env() -> None:
    """确保本地 Gradio 启动不受代理或本机网络拦截影响。"""
    localhost_items = ["127.0.0.1", "localhost"]
    for key in ("NO_PROXY", "no_proxy"):
        current = [x.strip() for x in os.environ.get(key, "").split(",") if x.strip()]
        for item in localhost_items:
            if item not in current:
                current.append(item)
        os.environ[key] = ",".join(current)

    for key in ("GRADIO_ANALYTICS_ENABLED", "GRADIO_SERVER_NAME"):
        if key not in os.environ:
            os.environ[key] = "False" if key == "GRADIO_ANALYTICS_ENABLED" else "127.0.0.1"

    if not getattr(httpx, "_tailect_localhost_patch", False):
        _orig_httpx_get = httpx.get

        def _patched_httpx_get(url, *args, **kwargs):
            url_text = str(url)
            if "startup-events" in url_text and ("127.0.0.1" in url_text or "localhost" in url_text):
                kwargs["trust_env"] = False
            return _orig_httpx_get(url, *args, **kwargs)

        httpx.get = _patched_httpx_get
        httpx._tailect_localhost_patch = True

# ================= 界面构建函数 =================

def build_demo(asr: Qwen3ASRModel, asr_ckpt: str, backend: str, aligner_ckpt: Optional[str] = None) -> gr.Blocks:
    lang_choices_disp, lang_map = _build_choices_and_map(asr.get_supported_languages())
    lang_choices = ["自动识别"] + lang_choices_disp
    has_aligner = bool(aligner_ckpt)
    
    custom_css = """
    #srt_preview { max-height: 400px; overflow-y: auto !important; }
    .gradio-container { max-width: none !important; }
    """

    with gr.Blocks(theme=gr.themes.Soft(), css=custom_css) as demo:
        asr_name = _friendly_checkpoint_name(asr_ckpt)
        aligner_name = _friendly_checkpoint_name(aligner_ckpt) if aligner_ckpt else "未加载"
        gr.Markdown(f"# 🎙️ Tailect ASR 方言转写工作台\n**推理后端:** `{backend}` | **识别模型:** `{asr_name}` | **对齐模型:** `{aligner_name}`\n\n支持本地音频上传、字幕导出与说话人角色识别。")
        
        with gr.Row():
            with gr.Column(scale=2): 
                input_media = gr.Audio(label="上传并预览音频 (支持直接拖入/在线裁剪)", type="filepath")
                lang_in = gr.Dropdown(label="语种选择", choices=lang_choices, value="自动识别")
                if has_aligner:
                    with gr.Group():
                        ts_in = gr.Checkbox(label="开启单词级时间戳", value=True)
                        punc_in = gr.Checkbox(label="跟随结果文本标点断句 (推荐)", value=True)
                        diarize_in = gr.Checkbox(
                            label="开启说话人角色识别",
                            value=False,
                            interactive=True,
                        )
                        max_chars_in = gr.Slider(label="单行最大字符数", minimum=5, maximum=100, value=40, step=1)
                else:
                    ts_in, punc_in, diarize_in, max_chars_in = gr.State(False), gr.State(True), gr.State(False), gr.State(40)
                btn = gr.Button("🚀 开始转写", variant="primary")
                
            with gr.Column(scale=4): 
                out_lang = gr.Textbox(label="检测语种", lines=1)
                out_text = gr.Textbox(label="识别文本", lines=6)
                out_srt_preview = gr.Code(label="SRT 字幕预览 (点击右上角复制)", lines=12, elem_id="srt_preview", language="markdown")
                out_srt_file = gr.File(label="下载 SRT 字幕文件")
                
            if has_aligner: # 右侧栏
                with gr.Column(scale=2): 
                    out_ts = gr.JSON(label="原始时间数据")
            else:
                out_ts = gr.State(None)

        def run(file_path: Any, lang_disp: str, return_ts: bool, split_punc: bool, diarize: bool, max_chars: int):
            if not file_path: return None, "未上传文件", None, None, ""
            processed_path = _convert_media_to_standard_wav(file_path)
            sd_result = None
            if diarize:
                gr.Info("正在分析说话人角色，请稍候...")
                try:
                    sd_pipe = get_sd_pipeline()
                    if sd_pipe:
                        sd_result = sd_pipe(processed_path)
                except Exception as e:
                    print(f"说话人角色识别运行失败，已自动跳过: {e}")
                    gr.Warning("说话人角色识别暂时不可用，已自动跳过并继续转写。")
            
            results = asr.transcribe(audio=processed_path, language=lang_map.get(lang_disp) if lang_disp != "自动识别" else None, return_time_stamps=bool(return_ts and has_aligner))
            r = results[0]
            
            ts_payload, srt_path, srt_content = None, None, ""
            if has_aligner and return_ts:
                ts_payload = [dict(text=getattr(t, "text", ""), start_time=getattr(t, "start_time", 0), end_time=getattr(t, "end_time", 0)) for t in (getattr(r, "time_stamps", []) or [])]
                srt_content = _generate_srt_content(getattr(r, "text", ""), ts_payload, sd_result, max_chars, split_punc)
                out_dir = os.path.join(os.getcwd(), "outputs")
                os.makedirs(out_dir, exist_ok=True)
                time_str = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
                srt_path = os.path.join(out_dir, f"Tailect_{time_str}.srt")
                with open(srt_path, "w", encoding="utf-8") as f: f.write(srt_content)
            
            if processed_path != file_path and os.path.exists(processed_path):
                try: os.remove(processed_path)
                except: pass
            return getattr(r, "language", ""), getattr(r, "text", ""), gr.update(value=ts_payload) if return_ts else None, srt_path, srt_content

        btn.click(run, inputs=[input_media, lang_in, ts_in, punc_in, diarize_in, max_chars_in], outputs=[out_lang, out_text, out_ts, out_srt_file, out_srt_preview])
            
    return demo

# ================= 启动函数 =================

def main(argv=None) -> int:
    parser = argparse.ArgumentParser(prog="tailect-asr-demo")
    parser.add_argument("--asr-checkpoint", required=True)
    parser.add_argument("--aligner-checkpoint", default=None)
    parser.add_argument("--backend", default="transformers", choices=["transformers", "vllm"])
    parser.add_argument("--cuda-visible-devices", default="0")
    parser.add_argument("--backend-kwargs", default=None)
    parser.add_argument("--aligner-kwargs", default=None)
    parser.add_argument("--ip", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8000)
    parser.add_argument("--share/--no-share", dest="share", default=False, action=argparse.BooleanOptionalAction)
    parser.add_argument("--concurrency", type=int, default=16)
    parser.add_argument("--ssl-certfile", default=None)
    parser.add_argument("--ssl-keyfile", default=None)
    parser.add_argument("--ssl-verify/--no-ssl-verify", dest="ssl_verify", default=True, action=argparse.BooleanOptionalAction)
    args = parser.parse_args(argv)
    
    if args.cuda_visible_devices: os.environ["CUDA_VISIBLE_DEVICES"] = args.cuda_visible_devices.strip()
    
    b_kwargs = _merge_dicts(_default_backend_kwargs(args.backend), _coerce_special_types(json.loads(args.backend_kwargs) if args.backend_kwargs else {}))
    
    forced_aligner, forced_aligner_kwargs = None, None # 修正点：初始化变量
    if args.aligner_checkpoint:
        forced_aligner = args.aligner_checkpoint
        # 修正点：将计算结果赋值给 forced_aligner_kwargs 而不是 a_kwargs
        forced_aligner_kwargs = _coerce_special_types(_merge_dicts(_default_aligner_kwargs(), json.loads(args.aligner_kwargs) if args.aligner_kwargs else {}))

    load_fn = Qwen3ASRModel.from_pretrained if args.backend == "transformers" else Qwen3ASRModel.LLM
    asr = load_fn(args.asr_checkpoint, forced_aligner=forced_aligner, forced_aligner_kwargs=forced_aligner_kwargs, **b_kwargs)
    
    demo = build_demo(asr, args.asr_checkpoint, args.backend, aligner_ckpt=args.aligner_checkpoint)
    _prepare_local_web_env()

    launch_host = (args.ip or "127.0.0.1").strip()
    if launch_host == "0.0.0.0":
        launch_host = "127.0.0.1"

    print(f"\n======================================================")
    print(f"服务器启动成功，正在弹出浏览器访问: http://127.0.0.1:{args.port}")
    print(f"======================================================\n")

    demo.queue(default_concurrency_limit=int(args.concurrency)).launch(
        server_name=launch_host,
        server_port=args.port,
        share=args.share,
        ssl_verify=args.ssl_verify,
        inbrowser=True
    )
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
